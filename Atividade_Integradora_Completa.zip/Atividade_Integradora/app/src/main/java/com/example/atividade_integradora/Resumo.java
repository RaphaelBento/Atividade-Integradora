package com.example.atividade_integradora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Resumo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo);
        Intent intent = getIntent();
        String Produtos = intent.getStringExtra("Produtos");

        if (Produtos.equals("ItensselecionadosTotal:R$:0.0")){
TextView MostraTelaSemProduto = findViewById(R.id.Precos);
MostraTelaSemProduto.setText("Favor selecionar ao menos um produto.");
        }
        else {
       // String precos = intent.getStringExtra("PrecoFeij");
        TextView PrecoV = findViewById(R.id.Precos);
        PrecoV.setText(Produtos);
        //ProdutosV.setText(Produtos);
    }
    }


    public void VoltarParaInicio(View view){
        Intent Voltar = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(Voltar);
    }
    public void IrparaFim(View view){
        Intent intent = new Intent(getApplicationContext(),CompraFinalizada.class);
        startActivity(intent);
    }
}
