package com.example.atividade_integradora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity {
CheckBox Feijao,Leite,Macarrao,Farofa,Refrigerante,BatataFrita;
 private Button botaoResultadoCompras;
    Double totalamount=0.0;
    StringBuilder result=new StringBuilder();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView texto = findViewById(R.id.IdTabelaProdutos);

this.botaoResultadoCompras = (Button)findViewById(R.id.btnFinalizar);
this.botaoResultadoCompras.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Feijao = (CheckBox)findViewById(R.id.IdFeijao);
        Leite = (CheckBox)findViewById(R.id.IdLeite);
        Macarrao = (CheckBox)findViewById(R.id.IdMacarrao);
        Farofa = (CheckBox)findViewById(R.id.IdFarofa);
        Refrigerante = (CheckBox)findViewById(R.id.IdRefrigerante);
        BatataFrita = (CheckBox)findViewById(R.id.IdBatata_frita);




        result.append("Itens selecionados:");
        if (Feijao.isChecked()){
            result.append("\nFeijão");
            totalamount+= 2.69;
        }
        if (Leite.isChecked()){
            result.append("\nLeite");
            totalamount+= 2.70;
        }
        if (Macarrao.isChecked()){
            result.append("\nMacarrão");
            totalamount+= 16.70;
        }
        if (Farofa.isChecked()){
            result.append("\nFarofa");
            totalamount+= 3.30;
        }
        if (Refrigerante.isChecked()){
            result.append("\nRefrigerante");
            totalamount+= 3.00;
        }
        if (BatataFrita.isChecked()){
            result.append("\nBatata-Frita");
            totalamount+= 5.00;
        }
        result.append("\nTotal: "+"R$" +totalamount);
        /*Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();
        String textao = "AGora funcionou";*/

TrocaPagina();
    }
});
    }

public  void TrocaPagina(){
    Intent intent = new Intent(this,Resumo.class);
    String valor = String.valueOf(totalamount);
    String Resultado = String.valueOf(result);
    intent.putExtra("ValorTotal",valor);
    intent.putExtra("Produtos",Resultado);
    startActivity(intent);
}



}