package com.example.atividade_integradora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Resumo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo);
        Intent intent = getIntent();
        String precos = intent.getStringExtra("Valor");
        Integer precocorrigido = Integer.parseInt(precos);
        String corre = precos.toString();
       // String precos = intent.getStringExtra("PrecoFeij");
        TextView PrecoV = findViewById(R.id.Precos);
        PrecoV.setText("Preços:" + corre);
    }


    public void VoltarParaInicio(View view){
        Intent Voltar = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(Voltar);
    }
}
